﻿namespace Harshikaben_patel_midterm_exam.Models
{
    public class Registration
    {
        public int id { get; set; }
        public string Firstname { get; set; }
        public string Password { get; set; }
        public string Gender {  get; set; }
        public string Email { get; set; }
        public string Address {  get; set; }
        public string Phone { get; set; }
        public string MobileNo {  get; set; }
        public string CurrentLocation {  get; set; }
        public int AnnualSalary {  get; set; }
        public string CurrentIndustry {  get; set; }
        public string Qualification {  get; set; }


    }
}
