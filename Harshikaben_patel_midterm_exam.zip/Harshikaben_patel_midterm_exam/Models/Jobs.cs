﻿namespace Harshikaben_patel_midterm_exam.Models
{
    public class Jobs
    {
      public int id {  get; set; }

        public string title { get; set; }
        public string category {  get; set; }
      public string owner_name { get; set; }
      

      public float hours {  get; set; }
      public int salary {  get; set; }
      public int experience {  get; set; }
      public string discription { get; set; }
      public string city { get; set; }
      public int active {  get; set; }

    }
}
