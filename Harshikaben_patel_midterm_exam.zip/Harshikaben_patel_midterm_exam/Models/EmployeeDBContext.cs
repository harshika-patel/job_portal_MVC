﻿using Microsoft.EntityFrameworkCore;

namespace Harshikaben_patel_midterm_exam.Models
{
    public class EmployeeDBContext: DbContext
    {
        public EmployeeDBContext(DbContextOptions options) : base(options)
        {
        }
        public DbSet<Registration> Registration { get; set; }
        public DbSet<Jobs> Jobs { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
        }
    }

}


